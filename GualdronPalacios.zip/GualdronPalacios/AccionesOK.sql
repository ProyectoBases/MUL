/*SELECT * FROM multimedias WHERE idDirector = 72; */
DELETE FROM directores WHERE id = 72;
/*SELECT * FROM multimedias WHERE idDirector = 72; */

/*SELECT * FROM categorias WHERE idMultimedia = 109; */
DELETE FROM multimedias WHERE id = 109;
/*SELECT * FROM categorias WHERE idMultimedia = 109; */

