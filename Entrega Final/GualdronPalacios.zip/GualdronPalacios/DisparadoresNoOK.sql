INSERT INTO series (id) VALUES(415);
INSERT INTO peliculas (id) VALUES(1524);
INSERT INTO documentales (id) VALUES (415);