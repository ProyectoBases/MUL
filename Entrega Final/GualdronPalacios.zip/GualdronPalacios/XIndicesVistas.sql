DROP INDEX multi;
DROP INDEX soli;


DROP VIEW temporadasU;
DROP VIEW capitulosSeri;
DROP VIEW capitulosDoc;