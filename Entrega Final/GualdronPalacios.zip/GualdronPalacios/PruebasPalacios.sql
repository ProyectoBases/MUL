/*Sebastian Jimenez es un nuevo cliente que quiere aventurar y probar nuevas aplicaciones para su entretenimiento y ha decidido probar Netflix.
Sebastian tiene 18 anios y quiere empezar esta aventura con toda, por eso ha decidido suscribirse al plan Premium*/

EXEC PA_ADMINISTRADOR.Adicionar_usuario ('sebasjimenez@gmail.com','Sebastian Jimenez Diaz',TO_DATE('21-4-2000','DD-MM-YYYY'));
EXEC PA_ADMINISTRADOR.Adicionar_suscripcion (1000,'Sebas',4,'sebasjimenez@gmail.com',0,1);

SELECT * FROM Usuarios WHERE correo = 'sebasjimenez@gmail.com';
SELECT * FROM Suscripciones WHERE id = 1000;


/*Sebastian quiere comenzar con el contenido disponible en la plataforma*/

SELECT PA_ADMINISTRADOR.Consultar_multimedia RETURN SYS_REFCURSOR;
