/*Soy un usuario y me gustaria saber las peliculas dirigidas por Daniela Cuadrado, para poder ver mas del estilo de esta directora*/
SELECT Multimedias.nombre, Categorias.nombre, Multimedias.calificacion, sinopsis, PremiosMultimedia.nombre
FROM Multimedias, Peliculas, Directores, CategoriasMultimedias, PremiosMultimedia, Categorias
WHERE Multimedias.id = Peliculas.id AND Multimedias.idDirector = Directores.id AND PremiosMultimedia.idMultimedia = Multimedias.id 
        AND CategoriasMultimedias.idMultimedia = Multimedias.id AND CategoriasMultimedias.idCategoria = Categorias.id AND Directores.nombre = 'daniela' AND Directores.apellido = 'cuadrado'
GROUP BY Multimedias.nombre, Categorias.nombre, Multimedias.calificacion, sinopsis, PremiosMultimedia.nombre;
