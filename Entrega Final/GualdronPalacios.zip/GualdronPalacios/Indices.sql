CREATE INDEX multi
ON multimedias(nombre);
/
CREATE INDEX soli
ON solicitudes(titulo);
/