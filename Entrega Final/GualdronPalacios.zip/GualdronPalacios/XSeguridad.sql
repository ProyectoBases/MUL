DROP ROLE administrador_;
DROP ROLE usuario;