CREATE ROLE administrador_;
CREATE ROLE usuario;


GRANT SELECT,UPDATE,INSERT ON multimedias TO administrador_;
GRANT SELECT,UPDATE,INSERT ON categorias TO administrador_;
GRANT SELECT,UPDATE,INSERT ON premiosMultimedia TO administrador_;
GRANT SELECT,UPDATE,INSERT ON categoriasMultimedias TO administrador_;
GRANT SELECT,UPDATE,INSERT ON peliculas TO administrador_;
GRANT SELECT,UPDATE,INSERT ON observa TO administrador_;
GRANT SELECT,UPDATE,INSERT ON series TO administrador_;
GRANT SELECT,UPDATE,INSERT ON documentales TO administrador_;
GRANT SELECT,UPDATE,INSERT ON temporadas TO administrador_;
GRANT SELECT,UPDATE,INSERT ON capitulosSeries TO administrador_;
GRANT SELECT,UPDATE,INSERT ON capitulosDocumentales TO administrador_;
GRANT SELECT,UPDATE,INSERT ON premiosActores TO administrador_;
GRANT SELECT,UPDATE,INSERT ON actores TO administrador_;
GRANT SELECT,UPDATE,INSERT ON actua TO administrador_;
GRANT SELECT,UPDATE,INSERT ON directores TO administrador_;
GRANT SELECT,UPDATE,INSERT ON suscripciones TO administrador_;
GRANT SELECT,UPDATE,INSERT ON plantillas TO administrador_;
GRANT SELECT,UPDATE,INSERT ON definicionVistas TO administrador_;
GRANT SELECT,UPDATE,INSERT ON usuarios TO administrador_;
GRANT SELECT,UPDATE,INSERT ON solicita TO administrador_;
GRANT SELECT,UPDATE,INSERT ON solicitudes TO administrador_;
GRANT SELECT,UPDATE,INSERT ON planes TO administrador_;


GRANT DELETE ON multimedias TO administrador_;
GRANT DELETE ON categorias TO administrador_;
GRANT DELETE ON premiosMultimedia TO administrador_;
GRANT DELETE ON categoriasMultimedias TO administrador_;
GRANT DELETE ON peliculas TO administrador_;
GRANT DELETE ON observa TO administrador_;
GRANT DELETE ON series TO administrador_;
GRANT DELETE ON documentales TO administrador_;
GRANT DELETE ON temporadas TO administrador_;
GRANT DELETE ON capitulosSeries TO administrador_;
GRANT DELETE ON capitulosDocumentales TO administrador_;
GRANT DELETE ON premiosActores TO administrador_;
GRANT DELETE ON actores TO administrador_;
GRANT DELETE ON actua TO administrador_;
GRANT DELETE ON suscripciones TO administrador_;
GRANT DELETE ON plantillas TO administrador_;
GRANT DELETE ON definicionVistas TO administrador_;
GRANT DELETE ON usuarios TO administrador_;
GRANT DELETE ON solicita TO administrador_;
GRANT DELETE ON solicitudes TO administrador_;
GRANT DELETE ON planes TO administrador_;



GRANT SELECT ON multimedias TO usuario;
GRANT SELECT ON categorias TO usuario;
GRANT SELECT ON premiosMultimedia TO usuario;
GRANT SELECT ON categoriasMultimedias TO usuario;
GRANT SELECT ON peliculas TO usuario;
GRANT SELECT ON observa TO usuario;
GRANT SELECT ON series TO usuario;
GRANT SELECT ON documentales TO usuario;
GRANT SELECT ON temporadas TO usuario;
GRANT SELECT ON capitulosSeries TO usuario;
GRANT SELECT ON capitulosDocumentales TO usuario;
GRANT SELECT ON premiosActores TO usuario;
GRANT SELECT ON actores TO usuario;
GRANT SELECT ON actua TO usuario;
GRANT SELECT ON directores TO usuario;
GRANT SELECT ON suscripciones TO usuario;
GRANT SELECT ON plantillas TO usuario;
GRANT SELECT ON definicionVistas TO usuario;
GRANT SELECT ON usuarios TO usuario;
GRANT SELECT ON solicita TO usuario;
GRANT SELECT ON solicitudes TO usuario;
GRANT SELECT ON planes TO usuario;